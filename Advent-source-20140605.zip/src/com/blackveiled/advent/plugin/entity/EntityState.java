package com.blackveiled.advent.plugin.entity;

/**
 *
 * @author Blackveiled
 */
public enum EntityState {

}
