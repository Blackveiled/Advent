package com.blackveiled.advent.plugin.inventory;

/**
 *
 * @author Blackveiled
 */
public enum Enchantment {

}
